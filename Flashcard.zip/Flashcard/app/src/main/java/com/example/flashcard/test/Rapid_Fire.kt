package com.example.flashcard.test

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R
import com.example.flashcard.folder.MathTests

class Rapid_Fire : AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.rapid_fire)

            // Back button logic
            val backButton: ImageView = findViewById(R.id.backButton)
            backButton.setOnClickListener {
                val intent = Intent(this, MathTests::class.java)
                startActivity(intent)
                finish() // Close the current activity to avoid stacking
            }
        }
    }
