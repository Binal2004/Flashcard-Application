package com.example.flashcard.datamodel

data class Users(
    val uid: String = "",
    val name: String? = null,
    val email: String? = null,
    val photoUrl: String? = null
)
