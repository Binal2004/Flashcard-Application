package com.example.flashcard.profile

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.flashcard.R
import com.example.flashcard.folder.FoldersFragment
import com.example.flashcard.HomeScreen.HomeFragment
import com.example.flashcard.live.LiveFragment

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile) // Ensure this matches your activity layout file

        // Set the default fragment to ProfileFragment
        replaceFragment(ProfileFragment())

        // Initialize bottom navigation buttons
        val iconHome: ImageView = findViewById(R.id.icon_home)
        val iconVideo: ImageView = findViewById(R.id.icon_video)
        val iconProfile: ImageView = findViewById(R.id.icon_profile)
        val iconFolders: ImageView = findViewById(R.id.icon_folders)

        // Set click listeners for navigation
        iconHome.setOnClickListener {
            replaceFragment(HomeFragment())
        }

        iconVideo.setOnClickListener {
            replaceFragment(LiveFragment())
        }

        iconProfile.setOnClickListener {
            replaceFragment(ProfileFragment())
        }

        iconFolders.setOnClickListener {
            replaceFragment(FoldersFragment())
        }
    }

    // Method to replace the current fragment with the selected one
    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.profilefragment, fragment) // Ensure profilefragment is the correct container ID in the XML
            .commit()
    }
}
