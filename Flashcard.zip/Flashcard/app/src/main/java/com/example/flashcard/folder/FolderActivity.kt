package com.example.flashcard.folder

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.flashcard.HomeScreen.HomeFragment
import com.example.flashcard.R
import com.example.flashcard.live.LiveFragment
import com.example.flashcard.profile.ProfileFragment
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class FolderActivity : AppCompatActivity(), FolderAdapter.OnFolderClickListener {
    private lateinit var recyclerView: RecyclerView
    private lateinit var folderAdapter: FolderAdapter
    private lateinit var fab: FloatingActionButton
    private lateinit var sharedViewModel: SharedViewModel
    private val folderList = mutableListOf<Folder>()

    // Firestore instance
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_folder)

        fab = findViewById(R.id.fab)
        sharedViewModel = ViewModelProvider(this)[SharedViewModel::class.java]

        // RecyclerView Setup
        folderAdapter = FolderAdapter(folderList, this)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = folderAdapter

        // Load folders from Firestore
        fetchFolders()

        // Handle FAB click for creating a new folder
        fab.setOnClickListener {
            showFolderDialog(null, null)
        }

        // Set the default fragment to FoldersFragment
        replaceFragment(FoldersFragment())

        // Handle bottom navigation
        findViewById<ImageView>(R.id.icon_home).setOnClickListener { replaceFragment(HomeFragment()) }
        findViewById<ImageView>(R.id.icon_video).setOnClickListener { replaceFragment(LiveFragment()) }
        findViewById<ImageView>(R.id.icon_profile).setOnClickListener { replaceFragment(ProfileFragment()) }
        findViewById<ImageView>(R.id.icon_folders).setOnClickListener { replaceFragment(FoldersFragment()) }
    }


    private fun showFolderDialog(folderId: String?, existingName: String?) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.activity_dialog, null)
        val folderNameEditText = dialogView.findViewById<EditText>(R.id.sessionNameInput)
        val createButton = dialogView.findViewById<Button>(R.id.createButton)

        if (existingName != null) {
            folderNameEditText.setText(existingName)
            createButton.text = "Update"
        } else {
            createButton.text = "Create"
        }

        val alertDialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        createButton.setOnClickListener {
            val folderName = folderNameEditText.text.toString().trim()
            if (folderName.isNotEmpty()) {
                if (folderId == null) {
                    createFolder(folderName)
                } else {
                    editFolder(folderId, folderName)
                }
                alertDialog.dismiss()
            } else {
                Toast.makeText(this, "Enter a folder name", Toast.LENGTH_SHORT).show()
            }
        }

        alertDialog.show()
    }

    private fun createFolder(folderName: String) {
        val folderData = hashMapOf(
            "name" to folderName,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection("flashcardFolders")
            .add(folderData)
            .addOnSuccessListener {
                Toast.makeText(this, "Folder Created", Toast.LENGTH_SHORT).show()
                fetchFolders() // Refresh list
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun editFolder(folderId: String, newName: String) {
        db.collection("flashcardFolders").document(folderId)
            .update("name", newName)
            .addOnSuccessListener {
                Toast.makeText(this, "Folder Updated", Toast.LENGTH_SHORT).show()
                fetchFolders()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error updating folder: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun deleteFolder(folderId: String) {
        db.collection("flashcardFolders").document(folderId)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(this, "Folder Deleted", Toast.LENGTH_SHORT).show()
                fetchFolders()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error deleting folder: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun fetchFolders() {
        db.collection("flashcardFolders")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    folderList.clear() // Clear the list before adding new data
                    for (document in snapshot.documents) {
                        val folder = Folder(
                            document.id,
                            document.getString("name") ?: "Unnamed Folder"
                        )
                        folderList.add(folder)
                    }
                    folderAdapter.notifyDataSetChanged() // Notify the adapter to update UI
                }
            }
    }


    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().replace(R.id.folderfragment, fragment).commit()
    }

    override fun onEditClick(folderId: String, folderName: String) {
        showFolderDialog(folderId, folderName)
    }

    override fun onDeleteClick(folderId: String) {
        deleteFolder(folderId)
    }
}
