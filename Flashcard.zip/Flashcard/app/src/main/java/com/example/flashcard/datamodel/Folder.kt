package com.example.flashcard.folder

data class Folder(
    val id: String = "",
    val name: String = "",
    val createdAt: Long = 0L // Ensure this field exists
)

