package com.example.flashcard.sciencetests

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R
import com.example.flashcard.folder.ScienceTests

class RapidFirePageActivity1 : AppCompatActivity() {

    private lateinit var timerTextView: TextView
    private lateinit var submitButton: Button
    private var correctAnswers = mutableMapOf<String, String>()
    private var score = 0
    private var timer: CountDownTimer? = null
    private val totalTime: Long = 60000  // 60 seconds
    private val interval: Long = 1000  // 1 second

    private lateinit var questionViews: List<TextView>
    private lateinit var answerInputs: List<EditText>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sience_rapidfire_main)  // Updated to science layout

        // Initialize UI elements
        timerTextView = findViewById(R.id.timerTextView)
        submitButton = findViewById(R.id.submitButton)

        // Back button logic
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            val intent = Intent(this, ScienceTests::class.java)
            startActivity(intent)
            finish()
        }

        // Initialize question and answer fields
        questionViews = listOf(
            findViewById(R.id.question1), findViewById(R.id.question2),
            findViewById(R.id.question3), findViewById(R.id.question4),
            findViewById(R.id.question10)
        )

        answerInputs = listOf(
            findViewById(R.id.answer1), findViewById(R.id.answer2),
            findViewById(R.id.answer3), findViewById(R.id.answer4),
            findViewById(R.id.answer10)
        )

        generateScienceQuestions()
        startTimer()

        submitButton.setOnClickListener {
            checkAnswers()
        }
    }

    private fun generateScienceQuestions() {
        correctAnswers.clear()

        val scienceQuestions = listOf(
            "What planet is known as the Red Planet?" to "Mars",
            "What gas do plants absorb from the atmosphere?" to "Carbon Dioxide",
            "What is the chemical symbol for water?" to "H2O",
            "What force pulls objects toward the Earth?" to "Gravity",
            "Which organ pumps blood through the body?" to "Heart",
            "What is the hardest natural substance on Earth?" to "Diamond",
            "What is the main gas found in the Earth's atmosphere?" to "Nitrogen",
            "What part of the plant conducts photosynthesis?" to "Leaves",
            "Which planet is closest to the Sun?" to "Mercury",
            "What is the boiling point of water in Celsius?" to "100"
        )

        for (i in questionViews.indices) {
            val (questionText, correctAnswer) = scienceQuestions[i]
            questionViews[i].text = questionText
            correctAnswers[questionText] = correctAnswer
        }
    }

    private fun startTimer() {
        timer = object : CountDownTimer(totalTime, interval) {
            override fun onTick(millisUntilFinished: Long) {
                timerTextView.text = "${millisUntilFinished / 1000}s"
            }

            override fun onFinish() {
                submitButton.performClick()
                timerTextView.text = "Time's up!"
            }
        }.start()
    }

    private fun checkAnswers() {
        score = 0

        for (i in questionViews.indices) {
            val userAnswer = answerInputs[i].text.toString().trim()
            val correctAnswer = correctAnswers[questionViews[i].text.toString()]

            if (userAnswer.equals(correctAnswer, ignoreCase = true)) {
                score++
            }
        }

        showScorePopup()
        timer?.cancel()
    }

    private fun showScorePopup() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_score_popup, null)
        val scoreTextView: TextView = dialogView.findViewById(R.id.scoreText)
        val okButton: Button = dialogView.findViewById(R.id.okButton)

        scoreTextView.text = "Your Score: $score/5"

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        okButton.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }
}
