package com.example.flashcard.folder

import android.animation.AnimatorInflater
import android.animation.AnimatorSet
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R

class MathsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.maths_main)

        // Find the flashcards
        val flashcard1 = findViewById<RelativeLayout>(R.id.frontSide)
        val flashcard2 = findViewById<RelativeLayout>(R.id.frontSide1)
        val flashcard3 = findViewById<RelativeLayout>(R.id.frontSide2)
        val flashcard4 = findViewById<RelativeLayout>(R.id.frontSide3)
        val flashcard5 = findViewById<RelativeLayout>(R.id.frontSide4)
        val flashcard6 = findViewById<RelativeLayout>(R.id.frontSide5)
        val flashcard7 = findViewById<RelativeLayout>(R.id.frontSide6)
        val flashcard8 = findViewById<RelativeLayout>(R.id.frontSide7)
        val flashcard9 = findViewById<RelativeLayout>(R.id.frontSide8)

        // Add flip functionality
        setupFlipAnimation(flashcard1, findViewById(R.id.backSide))
        setupFlipAnimation(flashcard2, findViewById(R.id.backSide1))
        setupFlipAnimation(flashcard3, findViewById(R.id.backSide2))
        setupFlipAnimation(flashcard4, findViewById(R.id.backSide3))
        setupFlipAnimation(flashcard5, findViewById(R.id.backSide4))
        setupFlipAnimation(flashcard6, findViewById(R.id.backSide5))
        setupFlipAnimation(flashcard7, findViewById(R.id.backSide6))
        setupFlipAnimation(flashcard8, findViewById(R.id.backSide7))
        setupFlipAnimation(flashcard9, findViewById(R.id.backSide8))

        val back = findViewById<ImageView>(R.id.backButton)
        back.setOnClickListener {
            val intent = Intent(this, FolderActivity::class.java) // Navigate to FolderActivity
            startActivity(intent)
        }

        val viewCard = findViewById<Button>(R.id.cardViewButton)
        viewCard.setOnClickListener {
            val intent = Intent(this, MathTests::class.java) // Navigate to FolderActivity
            startActivity(intent)
        }
    }

    private fun setupFlipAnimation(frontView: View, backView: View) {
        val scale = applicationContext.resources.displayMetrics.density
        frontView.cameraDistance = 8000 * scale
        backView.cameraDistance = 8000 * scale

        val frontAnimator = AnimatorInflater.loadAnimator(this, R.animator.card_flip_front) as AnimatorSet
        val backAnimator = AnimatorInflater.loadAnimator(this, R.animator.card_flip_back) as AnimatorSet

        frontView.setOnClickListener {
            frontAnimator.setTarget(frontView)
            backAnimator.setTarget(backView)
            frontAnimator.start()
            backAnimator.start()

            frontView.visibility = View.GONE
            backView.visibility = View.VISIBLE
        }

        backView.setOnClickListener {
            frontAnimator.setTarget(backView)
            backAnimator.setTarget(frontView)
            frontAnimator.start()
            backAnimator.start()

            frontView.visibility = View.VISIBLE
            backView.visibility = View.GONE
        }
    }
}
