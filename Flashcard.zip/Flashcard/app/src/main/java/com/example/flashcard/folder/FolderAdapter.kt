package com.example.flashcard.folder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.flashcard.R

class FolderAdapter(
    private val folderList: List<Folder>,
    private val listener: OnFolderClickListener
) : RecyclerView.Adapter<FolderAdapter.FolderViewHolder>() {

    interface OnFolderClickListener {
        fun onEditClick(folderId: String, folderName: String)
        fun onDeleteClick(folderId: String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FolderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false)
        return FolderViewHolder(view)
    }

    override fun onBindViewHolder(holder: FolderViewHolder, position: Int) {
        val folder = folderList[position]
        holder.bind(folder)
    }

    override fun getItemCount(): Int {
        return folderList.size
    }

    inner class FolderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val folderName: TextView = itemView.findViewById(R.id.folderName)
        private val editButton: ImageView = itemView.findViewById(R.id.rename)
        private val deleteButton: ImageView = itemView.findViewById(R.id.delete)

        fun bind(folder: Folder) {
            folderName.text = folder.name

            editButton.setOnClickListener {
                listener.onEditClick(folder.id, folder.name)
            }

            deleteButton.setOnClickListener {
                listener.onDeleteClick(folder.id)
            }
        }
    }

    fun updateFolders(newFolders: List<Folder>) {
        (folderList as MutableList).clear()
        (folderList as MutableList).addAll(newFolders)
        notifyDataSetChanged()
    }
}