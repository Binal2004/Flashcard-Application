package com.example.flashcard.HomeScreen

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.flashcard.R
import com.example.flashcard.folder.ComputerActivity
import com.example.flashcard.folder.Folder
import com.example.flashcard.folder.FolderAdapter
import com.example.flashcard.folder.MathsActivity
import com.example.flashcard.folder.ScienceActivity
import com.example.flashcard.folder.SharedViewModel
import com.example.flashcard.live.LiveActivity
import com.example.flashcard.profile.ProfileActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class HomeFragment : Fragment(), FolderAdapter.OnFolderClickListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var folderAdapter: FolderAdapter
    private lateinit var sharedViewModel: SharedViewModel
    private val folderList = mutableListOf<Folder>()
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.activity_fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recyclerView12)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        folderAdapter = FolderAdapter(folderList, this)
        recyclerView.adapter = folderAdapter
        sharedViewModel = ViewModelProvider(requireActivity())[SharedViewModel::class.java]

        setupNavigation(view)
        loadFoldersFromFirestore()
    }

    private fun setupNavigation(view: View) {
        // View All Button
        view.findViewById<Button>(R.id.view_all_button).setOnClickListener {
            startActivity(Intent(requireContext(), LiveActivity::class.java))
        }

        // Live Session
        view.findViewById<HorizontalScrollView>(R.id.sessions).setOnClickListener {
            startActivity(Intent(requireContext(), LiveActivity::class.java))
        }

        // Profile Image and Username
        view.findViewById<ImageView>(R.id.profile_image).setOnClickListener {
            startActivity(Intent(requireContext(), ProfileActivity::class.java))
        }

        view.findViewById<TextView>(R.id.username).setOnClickListener {
            startActivity(Intent(requireContext(), ProfileActivity::class.java))
        }

        // Subject Sections
        view.findViewById<LinearLayout>(R.id.mathematics).setOnClickListener {
            startActivity(Intent(requireContext(), MathsActivity::class.java))
        }

        view.findViewById<LinearLayout>(R.id.science).setOnClickListener {
            startActivity(Intent(requireContext(), ScienceActivity::class.java))
        }

        view.findViewById<LinearLayout>(R.id.computer).setOnClickListener {
            startActivity(Intent(requireContext(), ComputerActivity::class.java))
        }
    }

    private fun loadFoldersFromFirestore() {
        db.collection("folders")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { value, error ->
                if (error != null) {
                    Log.e("Firestore Error", error.message.toString())
                    return@addSnapshotListener
                }

                folderList.clear()
                value?.forEach { doc ->
                    val folder = doc.toObject(Folder::class.java).copy(id = doc.id)
                    folderList.add(folder)
                }
                folderAdapter.updateFolders(folderList)
            }
    }

    // Implement FolderAdapter.OnFolderClickListener methods
    override fun onEditClick(folderId: String, folderName: String) {
        (activity as? HomeActivity)?.showEditFolderDialog(folderId, folderName)
    }

    override fun onDeleteClick(folderId: String) {
        (activity as? HomeActivity)?.showDeleteConfirmationDialog(folderId)
    }
}