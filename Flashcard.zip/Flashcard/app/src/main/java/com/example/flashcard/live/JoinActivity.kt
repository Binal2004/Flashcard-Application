package com.example.flashcard.live

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R

class JoinActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_join)

        val joinButton: Button = findViewById(R.id.createButton)

        // Find the back button
        val back: ImageView = findViewById(R.id.backButton)
        back.setOnClickListener {
            val intent = Intent(this, LiveActivity::class.java)
            startActivity(intent)
            finish() // Close the current activity to prevent stacking
        }

        joinButton.setOnClickListener {
            val intent = Intent(this, VideoPlayerActivity::class.java)
            startActivity(intent)
        }
    }
}
