package com.example.flashcard.folder

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.flashcard.R
import com.example.flashcard.live.LiveActivity
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class FoldersFragment : Fragment(), FolderAdapter.OnFolderClickListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var folderAdapter: FolderAdapter
    private lateinit var sharedViewModel: SharedViewModel
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val folderList = mutableListOf<Folder>() // Maintain list of folders

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.activity_fragment_folders, container, false)

        recyclerView = view.findViewById(R.id.recyclerViewFolders)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Initialize adapter with empty list and listener
        folderAdapter = FolderAdapter(folderList, this)
        recyclerView.adapter = folderAdapter

        setupNavigation(view)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedViewModel = ViewModelProvider(requireActivity())[SharedViewModel::class.java]

        // Fetch folders from Firestore
        fetchFolders()

        // Observe LiveData to update UI
        sharedViewModel.foldersLiveData.observe(viewLifecycleOwner) { newFolders ->
            folderList.clear()  // Clear old list
            folderList.addAll(newFolders)  // Add new folders
            folderAdapter.notifyDataSetChanged()  // Refresh UI
            Log.d("Folder", "Fetched ${newFolders.size} folders")
        }
    }

    private fun fetchFolders() {
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            Toast.makeText(requireContext(), "User not logged in!", Toast.LENGTH_SHORT).show()
            return
        }

        db.collection("folders")
            .whereEqualTo("ownerId", user.uid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    Log.e("Firestore", "Error fetching folders", e)
                    return@addSnapshotListener
                }

                val fetchedFolders = snapshots?.documents?.mapNotNull { doc ->
                    doc.toObject(Folder::class.java)?.copy(id = doc.id)
                } ?: emptyList()

                folderList.clear()
                folderList.addAll(fetchedFolders)
                folderAdapter.notifyDataSetChanged()
            }
    }

    private fun setupNavigation(view: View) {
        view.findViewById<LinearLayout>(R.id.mathflashcard).setOnClickListener {
            startActivity(Intent(requireContext(), MathsActivity::class.java))
        }
        view.findViewById<LinearLayout>(R.id.scienceflashcard).setOnClickListener {
            startActivity(Intent(requireContext(), ScienceActivity::class.java))
        }
        view.findViewById<LinearLayout>(R.id.computerflashcard).setOnClickListener {
            startActivity(Intent(requireContext(), ComputerActivity::class.java))
        }
        view.findViewById<ImageView>(R.id.backButton).setOnClickListener {
            startActivity(Intent(requireContext(), LiveActivity::class.java))
        }
    }

    private fun showCreateFolderDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("New Folder")

        val input = EditText(requireContext())
        input.hint = "Enter folder name"
        builder.setView(input)

        builder.setPositiveButton("Create") { _, _ ->
            val folderName = input.text.toString().trim()
            if (folderName.isNotEmpty()) {
                createFolder(folderName)
            } else {
                Toast.makeText(requireContext(), "Folder name cannot be empty!", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun createFolder(folderName: String) {
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            Toast.makeText(requireContext(), "User not logged in!", Toast.LENGTH_SHORT).show()
            return
        }

        val folderData = hashMapOf(
            "name" to folderName,
            "ownerId" to user.uid,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection("folders")
            .add(folderData)
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Folder Created", Toast.LENGTH_SHORT).show()
                fetchFolders() // Refresh list
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onEditClick(folderId: String, folderName: String) {
        showEditFolderDialog(folderId, folderName)
    }

    override fun onDeleteClick(folderId: String) {
        showDeleteConfirmationDialog(folderId)
    }

    private fun showEditFolderDialog(folderId: String, currentName: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Rename Folder")

        val input = EditText(requireContext())
        input.setText(currentName)
        builder.setView(input)

        builder.setPositiveButton("Update") { _, _ ->
            val newFolderName = input.text.toString().trim()
            if (newFolderName.isNotEmpty()) {
                updateFolderName(folderId, newFolderName)
            } else {
                Toast.makeText(requireContext(), "Folder name cannot be empty!", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun updateFolderName(folderId: String, newName: String) {
        db.collection("folders").document(folderId)
            .update("name", newName)
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Folder Renamed", Toast.LENGTH_SHORT).show()
                fetchFolders()
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showDeleteConfirmationDialog(folderId: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Delete Folder")
        builder.setMessage("Are you sure you want to delete this folder?")

        builder.setPositiveButton("Delete") { _, _ ->
            deleteFolder(folderId)
        }

        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun deleteFolder(folderId: String) {
        db.collection("folders").document(folderId)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Folder Deleted", Toast.LENGTH_SHORT).show()
                fetchFolders()
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun isGooglePlayServicesAvailable(): Boolean {
        val googleApiAvailability = GoogleApiAvailability.getInstance()
        val resultCode = googleApiAvailability.isGooglePlayServicesAvailable(requireContext())
        return resultCode == ConnectionResult.SUCCESS
    }
}
