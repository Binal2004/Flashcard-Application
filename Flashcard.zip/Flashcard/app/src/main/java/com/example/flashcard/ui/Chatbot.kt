package com.example.flashcard.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.flashcard.data.Message
import com.example.flashcard.databinding.ActivityChatbotBinding
import com.example.flashcard.utils.BotResponse
import com.example.flashcard.utils.Constants.OPEN_GOOGLE
import com.example.flashcard.utils.Constants.OPEN_SEARCH
import com.example.flashcard.utils.Constants.RECEIVE_ID
import com.example.flashcard.utils.Time
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Chatbot : AppCompatActivity() {

    private lateinit var binding: ActivityChatbotBinding
    private lateinit var adapter: MessagingAdapter
    private val botList = listOf("Peter", "Francesca", "Luigi", "Igor")
    private val messagesList = mutableListOf<Message>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatbotBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupClickEvents()

        val random = (0..3).random()
        customMessage("Hello! Today you're speaking with ${botList[random]}, how may I help?")
    }

    private fun setupClickEvents() {
        // Send a message
        binding.btnSend.setOnClickListener {
            sendMessage()
        }

        // Scroll back to correct position when user clicks on text view
        binding.etMessage.setOnClickListener {
            lifecycleScope.launch {
                delay(100)
                binding.rvMessages.scrollToPosition(adapter.itemCount - 1)
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = MessagingAdapter()
        binding.rvMessages.adapter = adapter
        binding.rvMessages.layoutManager = LinearLayoutManager(this)
    }

    private fun sendMessage() {
        val message = binding.etMessage.text.toString().trim()
        val timeStamp = Time.timeStamp()

        if (message.isNotEmpty()) {
            binding.etMessage.setText("")

            adapter.insertMessage(Message(message, RECEIVE_ID, timeStamp))
            binding.rvMessages.scrollToPosition(adapter.itemCount - 1)

            botResponse(message)
        }
    }

    private fun botResponse(message: String) {
        val timeStamp = Time.timeStamp()

        lifecycleScope.launch {
            delay(1000)
            withContext(Dispatchers.Main) {
                val response = BotResponse.basicResponses(message)
                adapter.insertMessage(Message(response, RECEIVE_ID, timeStamp))
                binding.rvMessages.scrollToPosition(adapter.itemCount - 1)

                when (response) {
                    OPEN_GOOGLE -> {
                        val site = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/"))
                        startActivity(site)
                    }

                    OPEN_SEARCH -> {
                        val searchTerm: String = message.substringAfter("search").trim()
                        val site = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$searchTerm"))
                        startActivity(site)
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        lifecycleScope.launch {
            delay(100)
            binding.rvMessages.scrollToPosition(adapter.itemCount - 1)
        }
    }

    private fun customMessage(message: String) {
        lifecycleScope.launch {
            delay(1000)
            withContext(Dispatchers.Main) {
                val timestamp = Time.timeStamp()
                adapter.insertMessage(Message(message, RECEIVE_ID, timestamp))
                binding.rvMessages.scrollToPosition(adapter.itemCount - 1)
            }
        }
    }
}
