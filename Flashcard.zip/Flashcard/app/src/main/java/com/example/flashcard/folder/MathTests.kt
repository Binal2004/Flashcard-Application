package com.example.flashcard.folder

import android.animation.AnimatorInflater
import android.animation.AnimatorSet
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R
import com.example.flashcard.mathtests.MCQPageActivity
import com.example.flashcard.mathtests.MatchColumnPageActivity
import com.example.flashcard.mathtests.RapidFirePageActivity

class MathTests : AppCompatActivity() {

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.math_tests_main)

            // Back button logic
            val back: ImageView = findViewById(R.id.backButton)
            back.setOnClickListener {
                finish() // Close the current activity and return to the previous one
            }

            // Test navigation buttons
            setupTestButtons()
        }

        private fun setupFlipAnimation(frontView: View, backView: View) {
            val scale = applicationContext.resources.displayMetrics.density
            frontView.cameraDistance = 8000 * scale
            backView.cameraDistance = 8000 * scale

            val frontAnimator =
                AnimatorInflater.loadAnimator(this, R.animator.card_flip_front) as AnimatorSet
            val backAnimator =
                AnimatorInflater.loadAnimator(this, R.animator.card_flip_back) as AnimatorSet

            frontView.setOnClickListener {
                frontAnimator.setTarget(frontView)
                backAnimator.setTarget(backView)
                frontAnimator.start()
                backAnimator.start()

                frontView.visibility = View.GONE
                backView.visibility = View.VISIBLE
            }

            backView.setOnClickListener {
                frontAnimator.setTarget(backView)
                backAnimator.setTarget(frontView)
                frontAnimator.start()
                backAnimator.start()

                frontView.visibility = View.VISIBLE
                backView.visibility = View.GONE
            }
        }

        private fun setupTestButtons() {
            // Navigate to MCQ Page
            val mcqButton =
                findViewById<LinearLayout>(R.id.testsContainer).findViewById<LinearLayout>(R.id.mcqButton)
            mcqButton.setOnClickListener {
                val intent = Intent(this, MCQPageActivity::class.java)
                startActivity(intent)
            }

            // Navigate to Match the Columns Page
            val matchColumnButton =
                findViewById<LinearLayout>(R.id.testsContainer).findViewById<LinearLayout>(R.id.matchColumnButton)
            matchColumnButton.setOnClickListener {
                val intent = Intent(this, MatchColumnPageActivity::class.java)
                startActivity(intent)
            }


            // Navigate to Rapid Fire Page
            val rapidFireButton =
                findViewById<LinearLayout>(R.id.testsContainer).findViewById<LinearLayout>(R.id.rapidFireButton)
            rapidFireButton.setOnClickListener {
                val intent = Intent(this, RapidFirePageActivity::class.java)
                startActivity(intent)
            }
        }
    }
