package com.example.flashcard.live

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.example.flashcard.HomeScreen.HomeActivity
import com.example.flashcard.R
import com.example.flashcard.live.CreateSessionActivity
import com.example.flashcard.live.JoinActivity

class LiveFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.activity_fragment_live, container, false)

        // Find the createSessionSection
        val createSessionSection: LinearLayout = view.findViewById(R.id.createSessionSection)
        createSessionSection.setOnClickListener {
            val intent = Intent(requireContext(), CreateSessionActivity::class.java)
            startActivity(intent)
        }

        val joinSession: LinearLayout = view.findViewById(R.id.joinSession)
        joinSession.setOnClickListener {
            val intent = Intent(requireContext(), JoinActivity::class.java)
            startActivity(intent)
        }

        val back: ImageView = view.findViewById(R.id.backButton)
        back.setOnClickListener {
            val intent = Intent(requireContext(), HomeActivity::class.java)
            startActivity(intent)
        }

        return view
    }
}
