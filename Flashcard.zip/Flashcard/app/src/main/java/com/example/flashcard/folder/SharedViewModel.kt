package com.example.flashcard.folder

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore

class SharedViewModel : ViewModel() {
    private val _foldersLiveData = MutableLiveData<List<Folder>>()
    val foldersLiveData: LiveData<List<Folder>> get() = _foldersLiveData

    fun fetchFolders() {
        val db = FirebaseFirestore.getInstance()
        db.collection("folders")
            .get()
            .addOnSuccessListener { documents ->
                val folderList = mutableListOf<Folder>()
                for (document in documents) {
                    val folder = document.toObject(Folder::class.java)
                    folderList.add(folder)
                }
                _foldersLiveData.postValue(folderList)  // Update LiveData
            }
            .addOnFailureListener { exception ->
                Log.e("Firestore", "Error fetching folders", exception)
            }
    }
}
