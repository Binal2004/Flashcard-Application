package com.example.flashcard.data

data class Message(val message: String, val id: String, val time: String)
