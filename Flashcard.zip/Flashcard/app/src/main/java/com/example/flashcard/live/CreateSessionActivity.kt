package com.example.flashcard.live

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R

class CreateSessionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.create_session)

        // Handle the custom back button
        val back: ImageView = findViewById(R.id.backButton)
        back.setOnClickListener {
            val intent = Intent(this, LiveActivity::class.java)
            startActivity(intent)
        }

        // Handle the session link click to open the browser
        val sessionLink: TextView = findViewById(R.id.sessionLink)
        sessionLink.setOnClickListener {
            val url = sessionLink.text.toString()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }
    }
}
