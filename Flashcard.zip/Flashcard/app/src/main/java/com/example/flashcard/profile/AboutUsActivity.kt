package com.example.flashcard.profile

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R

class AboutUsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.about_us)

        // Find the back button
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            // Navigate back to ProfileActivity
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
            finish() // Optional: To avoid stacking activities
        }
    }
}
