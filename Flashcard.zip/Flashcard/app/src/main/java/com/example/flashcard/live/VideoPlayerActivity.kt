package com.example.flashcard.live

import android.net.Uri
import android.os.Bundle
import android.widget.MediaController
import android.widget.VideoView
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.flashcard.R
import com.example.flashcard.databinding.ActivityVideoPlayerBinding

class VideoPlayerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_player)

        // Find the VideoView in the layout
        val videoView: VideoView = findViewById(R.id.videoView)

        // Get video path from intent (optional, for flexibility)
        val videoPath = intent.getStringExtra("VIDEO_URI") ?: "android.resource://${packageName}/${R.raw.zoomvideo}"
        val videoUri = Uri.parse(videoPath)

        // Set up the video
        videoView.setVideoURI(videoUri)

        // Add media controls (play, pause, forward, rewind)
        val mediaController = MediaController(this)
        mediaController.setAnchorView(videoView)
        videoView.setMediaController(mediaController)

        // Start video automatically
        videoView.start()
    }
}
