package com.example.flashcard.folder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.example.flashcard.R

class FlashcardAdapter(private var flashcards: MutableList<Flashcard>) :
    RecyclerView.Adapter<FlashcardAdapter.FlashcardViewHolder>() {

    private var filteredFlashcards: MutableList<Flashcard> = flashcards.toMutableList()

    class FlashcardViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val flashcardFront: EditText = view.findViewById(R.id.flashcardFront) // Correct ID
        private val flashcardBack: EditText = view.findViewById(R.id.flashcardBack)   // Correct ID

        fun bind(flashcard: Flashcard) {
            flashcardFront.setText(flashcard.term) // Set term (question)
            flashcardBack.setText(flashcard.definition) // Set definition (answer)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlashcardViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_flashcard, parent, false)
        return FlashcardViewHolder(view)
    }

    override fun onBindViewHolder(holder: FlashcardViewHolder, position: Int) {
        holder.bind(filteredFlashcards[position])
    }

    override fun getItemCount(): Int = filteredFlashcards.size

    // Function to filter flashcards based on search query
    fun filterFlashcards(query: String) {
        filteredFlashcards = if (query.isEmpty()) {
            flashcards.toMutableList()
        } else {
            flashcards.filter { it.term.contains(query, ignoreCase = true) }.toMutableList()
        }
        notifyDataSetChanged()
    }

    // Function to update the flashcards list
    fun updateFlashcards(newFlashcards: List<Flashcard>) {
        flashcards.clear()
        flashcards.addAll(newFlashcards)
        filterFlashcards("") // Reset filter
    }
}
