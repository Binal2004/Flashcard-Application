package com.example.flashcard.authentication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.HomeScreen.HomeActivity
import com.example.flashcard.R
import com.google.firebase.auth.FirebaseAuth

class WelcomeScreen : AppCompatActivity() {
    lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.welcome_screen)


        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        val logIn = findViewById<Button>(R.id.login_button)
        val signUp = findViewById<Button>(R.id.signupButton)

        logIn.setOnClickListener {
            Toast.makeText(this, "Log In clicked", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }

        signUp.setOnClickListener{
            val intent= Intent(this, SignUp::class.java)
            startActivity(intent)
        }
    }
    override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // Debugging
            Log.d("WelcomePage1", "User is already signed in: ${currentUser.uid}")
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        } else {
            Log.d("WelcomePage1", "No user signed in.")
        }
    }
}