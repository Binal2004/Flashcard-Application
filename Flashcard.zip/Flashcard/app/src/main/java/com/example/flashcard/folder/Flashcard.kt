package com.example.flashcard.folder

data class Flashcard(
    val id: String = "",
    val term: String = "",
    val definition: String = ""
)

