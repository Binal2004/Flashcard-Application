package com.example.flashcard.computertests

import android.graphics.Color
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R

class MatchColumnPageActivity2 : AppCompatActivity() {

    private var selectedTerm: FrameLayout? = null
    private var selectedTermText: String? = null
    private var selectedDefinition: FrameLayout? = null
    private var selectedDefinitionText: String? = null

    private val correctPairs = hashMapOf(
        "CPU" to "Central Processing Unit",
        "RAM" to "Random Access Memory",
        "SSD" to "Solid State Drive",
        "GPU" to "Graphics Processing Unit",
        "HTTP" to "HyperText Transfer Protocol"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.computer_matchthecolumn_main)

        // Initialize term and definition frames
        val terms = listOf(
            findViewById<FrameLayout>(R.id.term1),
            findViewById<FrameLayout>(R.id.term2),
            findViewById<FrameLayout>(R.id.term3),
            findViewById<FrameLayout>(R.id.term4),
            findViewById<FrameLayout>(R.id.term5)
        )

        val definitions = listOf(
            findViewById<FrameLayout>(R.id.definition1),
            findViewById<FrameLayout>(R.id.definition2),
            findViewById<FrameLayout>(R.id.definition3),
            findViewById<FrameLayout>(R.id.definition4),
            findViewById<FrameLayout>(R.id.definition5)
        )

        val termTexts = listOf(
            findViewById<TextView>(R.id.termText1),
            findViewById<TextView>(R.id.termText2),
            findViewById<TextView>(R.id.termText3),
            findViewById<TextView>(R.id.termText4),
            findViewById<TextView>(R.id.termText5)
        )

        val definitionTexts = listOf(
            findViewById<TextView>(R.id.definitionText1),
            findViewById<TextView>(R.id.definitionText2),
            findViewById<TextView>(R.id.definitionText3),
            findViewById<TextView>(R.id.definitionText4),
            findViewById<TextView>(R.id.definitionText5)
        )

        // Shuffle definitions before displaying
        shuffleDefinitions(definitionTexts)

        // Set click listeners for terms
        for (i in terms.indices) {
            terms[i].setOnClickListener { selectTerm(terms[i], termTexts[i].text.toString()) }
        }

        // Set click listeners for definitions
        for (i in definitions.indices) {
            definitions[i].setOnClickListener { selectDefinition(definitions[i], definitionTexts[i].text.toString()) }
        }
    }

    private fun shuffleDefinitions(definitionTexts: List<TextView>) {
        // Extract definition texts and shuffle them
        val shuffledDefinitions = definitionTexts.map { it.text.toString() }.shuffled()

        // Assign shuffled definitions back to the TextViews
        for (i in definitionTexts.indices) {
            definitionTexts[i].text = shuffledDefinitions[i]
        }
    }

    private fun selectTerm(term: FrameLayout, text: String) {
        selectedTerm?.setBackgroundResource(R.drawable.rounded_card) // Reset previous selection
        selectedTerm = term
        selectedTermText = text
        term.setBackgroundColor(Color.YELLOW) // Highlight selected term
    }

    private fun selectDefinition(definition: FrameLayout, text: String) {
        if (selectedTerm == null) {
            Toast.makeText(this, "Select a computer term first!", Toast.LENGTH_SHORT).show()
            return
        }

        selectedDefinition = definition
        selectedDefinitionText = text

        checkMatch()
    }

    private fun checkMatch() {
        if (selectedTermText != null && selectedDefinitionText != null) {
            if (correctPairs[selectedTermText] == selectedDefinitionText) {
                selectedTerm?.setBackgroundColor(Color.GREEN)
                selectedDefinition?.setBackgroundColor(Color.GREEN)
                selectedTerm?.isClickable = false
                selectedDefinition?.isClickable = false

                Toast.makeText(this, "Correct match!", Toast.LENGTH_SHORT).show()
            } else {
                selectedTerm?.setBackgroundColor(Color.RED)
                selectedDefinition?.setBackgroundColor(Color.RED)

                Toast.makeText(this, "Incorrect! Try again.", Toast.LENGTH_SHORT).show()

                selectedTerm?.postDelayed({
                    selectedTerm?.setBackgroundResource(R.drawable.rounded_card)
                    selectedDefinition?.setBackgroundResource(R.drawable.rounded_card)
                    selectedTerm = null
                    selectedDefinition = null
                }, 1000)
            }

            // Reset selection variables
            selectedTerm = null
            selectedDefinition = null
        }
    }
}
