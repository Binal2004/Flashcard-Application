package com.example.flashcard.sciencetests

import android.graphics.Color
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R

class MatchColumnPageActivity1 : AppCompatActivity() {

    private var selectedProblem: FrameLayout? = null
    private var selectedProblemText: String? = null
    private var selectedAnswer: FrameLayout? = null
    private var selectedAnswerText: String? = null

    private val correctPairs = hashMapOf(
        "H2O" to "Water",
        "O2" to "Oxygen",
        "CO2" to "Carbon Dioxide",
        "NaCl" to "Salt",
        "C6H12O6" to "Glucose"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.science_matchthecolumn_main)

        val problems = listOf(
            findViewById<FrameLayout>(R.id.problem1),
            findViewById<FrameLayout>(R.id.problem2),
            findViewById<FrameLayout>(R.id.problem3),
            findViewById<FrameLayout>(R.id.problem4),
            findViewById<FrameLayout>(R.id.problem5)
        )

        val answers = listOf(
            findViewById<FrameLayout>(R.id.answer1),
            findViewById<FrameLayout>(R.id.answer2),
            findViewById<FrameLayout>(R.id.answer3),
            findViewById<FrameLayout>(R.id.answer4),
            findViewById<FrameLayout>(R.id.answer5)
        )

        val problemTexts = listOf(
            findViewById<TextView>(R.id.problemText1),
            findViewById<TextView>(R.id.problemText2),
            findViewById<TextView>(R.id.problemText3),
            findViewById<TextView>(R.id.problemText4),
            findViewById<TextView>(R.id.problemText5)
        )

        val answerTexts = listOf(
            findViewById<TextView>(R.id.answerText1),
            findViewById<TextView>(R.id.answerText2),
            findViewById<TextView>(R.id.answerText3),
            findViewById<TextView>(R.id.answerText4),
            findViewById<TextView>(R.id.answerText5)
        )

        shuffleAnswers(answerTexts)

        for (i in problems.indices) {
            problems[i].setOnClickListener { selectProblem(problems[i], problemTexts[i].text.toString()) }
        }

        for (i in answers.indices) {
            answers[i].setOnClickListener { selectAnswer(answers[i], answerTexts[i].text.toString()) }
        }
    }

    private fun shuffleAnswers(answerTexts: List<TextView>) {
        val shuffledAnswers = answerTexts.map { it.text.toString() }.shuffled()
        for (i in answerTexts.indices) {
            answerTexts[i].text = shuffledAnswers[i]
        }
    }

    private fun selectProblem(problem: FrameLayout, text: String) {
        selectedProblem?.setBackgroundResource(R.drawable.rounded_card)
        selectedProblem = problem
        selectedProblemText = text
        problem.setBackgroundColor(Color.YELLOW)
    }

    private fun selectAnswer(answer: FrameLayout, text: String) {
        if (selectedProblem == null) {
            Toast.makeText(this, "Select a science term first!", Toast.LENGTH_SHORT).show()
            return
        }

        selectedAnswer = answer
        selectedAnswerText = text

        checkMatch()
    }

    private fun checkMatch() {
        if (selectedProblemText != null && selectedAnswerText != null) {
            if (correctPairs[selectedProblemText] == selectedAnswerText) {
                selectedProblem?.setBackgroundColor(Color.GREEN)
                selectedAnswer?.setBackgroundColor(Color.GREEN)
                selectedProblem?.isClickable = false
                selectedAnswer?.isClickable = false

                Toast.makeText(this, "Correct match!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Incorrect! Try again.", Toast.LENGTH_SHORT).show()
            }

            selectedProblem = null
            selectedAnswer = null
        }
    }
}
