package com.example.flashcard.authentication

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.example.flashcard.HomeScreen.HomeActivity
import com.example.flashcard.R
import com.example.flashcard.datamodel.Users
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.*
import com.google.firebase.firestore.FirebaseFirestore

class AuthHelper(private val activity: Activity, private val firebaseAuth: FirebaseAuth) {
    private lateinit var googleSignInClient: GoogleSignInClient


    companion object {
        const val RC_SIGN_IN = 9001
    }

    fun configureGoogleSignIn(context: Context) {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(R.string.default_web_client_Id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(context, gso)
    }



    fun getGoogleSignInIntent(): Intent {
        return googleSignInClient.signInIntent
    }

    fun handleGoogleSignInResult(data: Intent?) {
        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            val account = task.getResult(ApiException::class.java)!!
            firebaseAuthWithGoogle(account)
        } catch (e: ApiException) {
            Toast.makeText(activity, "Google sign in failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun firebaseAuthWithGoogle(account: GoogleSignInAccount) {
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        firebaseAuth.signInWithCredential(credential)
            .addOnCompleteListener(activity) { task ->
                if (task.isSuccessful) {
                    val user = firebaseAuth.currentUser
                    user?.let {
                        saveUserToFirestore(it)
                    }
                    activity.startActivity(Intent(activity, HomeActivity::class.java))
                    activity.finish()
                } else {
                    Toast.makeText(activity, "Firebase Authentication failed.", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun saveUserToFirestore(user: FirebaseUser, email: String? = null) {
        val userData = Users(
            uid = user.uid,
            name = user.displayName,
            email = email ?: user.email,
            photoUrl = user.photoUrl?.toString()
        )

        val db = FirebaseFirestore.getInstance()
        db.collection("Users").document(user.uid)
            .set(userData)
            .addOnSuccessListener {
                Log.d("AuthHelper", "User data saved successfully in Firestore")
            }
            .addOnFailureListener { e ->
                Log.e("AuthHelper", "Error saving user data in Firestore: $e")
            }
    }

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (requestCode == RC_SIGN_IN) {
            handleGoogleSignInResult(data)
        }
    }
}
