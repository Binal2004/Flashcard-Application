package com.example.flashcard.authentication

import com.example.flashcard.HomeScreen.HomeActivity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage

class Login : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var signInButton: Button
    private lateinit var signUpTextView: TextView
    private lateinit var forgotPasswordTextView: TextView
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var authHelper: AuthHelper
    private lateinit var firestore: FirebaseFirestore
    private lateinit var editProfileImage:ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        // Initialize Firebase Auth and Firestore
        firebaseAuth = FirebaseAuth.getInstance()
        authHelper = AuthHelper(this, firebaseAuth)
        firestore = FirebaseFirestore.getInstance()

        // Configure Google and Facebook Sign-In
        authHelper.configureGoogleSignIn(this)


        // Find views
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        signInButton = findViewById(R.id.signInButton)
        signUpTextView = findViewById(R.id.signup_textview)
        forgotPasswordTextView = findViewById(R.id.forgotPasswordTextView)
        val googleLoginButton: Button = findViewById(R.id.googleLoginButton)

        // Sign up click listener
        signUpTextView.setOnClickListener {
            startActivity(Intent(this, SignUp::class.java))
        }

        // Forgot password click listener
        forgotPasswordTextView.setOnClickListener {
            showForgotPasswordBottomSheet()
        }

        // Sign in click listener
        signInButton.setOnClickListener {
            handleEmailAndPasswordSignIn()
        }

        // Google Sign-In button click listener
        googleLoginButton.setOnClickListener {
            val signInIntent = authHelper.getGoogleSignInIntent()
            startActivityForResult(signInIntent, AuthHelper.RC_SIGN_IN)
        }


    }



    private fun handleEmailAndPasswordSignIn() {
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        if (email.isEmpty()) {
            emailEditText.error = "Email is required."
            emailEditText.requestFocus()
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.error = "Please enter a valid email."
            emailEditText.requestFocus()
            return
        }

        if (password.isEmpty()) {
            passwordEditText.error = "Password is required."
            passwordEditText.requestFocus()
            return
        }

        firebaseAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val currentUser = firebaseAuth.currentUser
                    if (currentUser != null) {
                        checkPendingEmail(currentUser.uid, currentUser.email!!)
                        fetchProfileImage(currentUser.uid)
                    } else {
                        Toast.makeText(this, "User is not authenticated.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Authentication failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun fetchProfileImage(userId: String) {
        val storageRef = FirebaseStorage.getInstance().reference.child("profile_images/$userId.jpg")

        storageRef.downloadUrl
            .addOnSuccessListener { uri ->
                val imageUrl = uri.toString()
                Log.d("FetchProfileImage", "Fetched image URL from Storage: $imageUrl")

                // ✅ Overwrite previous cache in SharedPreferences
                val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
                with(sharedPreferences.edit()) {
                    putString("profileImage", imageUrl)
                    apply()
                }

                // ✅ Navigate to Home
                navigateToHome()
            }
            .addOnFailureListener { e ->
                Log.e("FetchProfileImage", "Failed to fetch profile image from Storage: ${e.message}")
                navigateToHome()
            }
    }

    private fun checkPendingEmail(userId: String, currentEmail: String) {
        firestore.collection("Users").document(userId).get()
            .addOnSuccessListener { document ->
                val pendingEmail = document.getString("pending_email")

                if (pendingEmail != null) {
                    if (currentEmail == pendingEmail && firebaseAuth.currentUser?.isEmailVerified == true) {
                        // Email matches the pending email and is verified
                        updateFirestoreEmail(userId, pendingEmail)
                    } else {
                        Toast.makeText(
                            this,
                            "Please verify the new email: $pendingEmail",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    // No pending email
                    navigateToHome()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to check pending email: ${e.message}", Toast.LENGTH_SHORT).show()
                navigateToHome()
            }
    }

    private fun updateFirestoreEmail(userId: String, newEmail: String) {
        firestore.collection("Users").document(userId).update("email", newEmail, "pending_email", null)
            .addOnSuccessListener {
                Toast.makeText(this, "Email updated successfully.", Toast.LENGTH_SHORT).show()
                navigateToHome()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to update email in Firestore: ${e.message}", Toast.LENGTH_SHORT).show()
                navigateToHome()
            }
    }

    private fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        authHelper.onActivityResult(requestCode, resultCode, data)
    }

    private fun showForgotPasswordBottomSheet() {
        val bottomSheetDialog = BottomSheetDialog(this)
        val view = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_forgot_password, null)
        bottomSheetDialog.setContentView(view)

        val resetEmailEditText = view.findViewById<EditText>(R.id.resetEmailEditText)
        val sendCodeButton = view.findViewById<Button>(R.id.sendCodeButton)

        sendCodeButton.setOnClickListener {
            val email = resetEmailEditText.text.toString().trim()

            if (email.isEmpty()) {
                resetEmailEditText.error = "Email is required."
                resetEmailEditText.requestFocus()
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                resetEmailEditText.error = "Please enter a valid email."
                resetEmailEditText.requestFocus()
                return@setOnClickListener
            }

            firebaseAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Reset email sent.", Toast.LENGTH_SHORT).show()
                        bottomSheetDialog.dismiss()
                    } else {
                        Toast.makeText(this, "Error sending reset email.", Toast.LENGTH_SHORT).show()
                    }
                }
        }
        bottomSheetDialog.show()
    }
}
