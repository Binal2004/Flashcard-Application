package com.example.flashcard.authentication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.HomeScreen.HomeActivity
import com.example.flashcard.R
import com.example.flashcard.datamodel.Users
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore

class SignUp : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var signUpButton: Button
    private lateinit var loginTextView: TextView
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var authHelper: AuthHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sign_up)

        // Initialize Firebase Auth
        firebaseAuth = FirebaseAuth.getInstance()
        authHelper = AuthHelper(this, firebaseAuth)

        // Configure Google and Facebook Sign-In
        authHelper.configureGoogleSignIn(this)


        // Find views
        nameEditText = findViewById(R.id.usernameInput)
        emailEditText = findViewById(R.id.emailInput)
        passwordEditText = findViewById(R.id.passwordInput)
        confirmPasswordEditText = findViewById(R.id.confirmPasswordInput)
        signUpButton = findViewById(R.id.registerButton)
        loginTextView = findViewById(R.id.alreadyAccount)
        val googleSignUpButton: Button = findViewById(R.id.googleLoginButton)

        // Login click listener
        loginTextView.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
        }

        // Sign up click listener
        signUpButton.setOnClickListener {
            handleEmailAndPasswordSignUp()
        }

        // Google Sign-Up button click listener
        googleSignUpButton.setOnClickListener {
            val signInIntent = authHelper.getGoogleSignInIntent()
            startActivityForResult(signInIntent, AuthHelper.RC_SIGN_IN)
        }


    }

    private fun handleEmailAndPasswordSignUp() {
        val name = nameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()
        val confirmPassword = confirmPasswordEditText.text.toString().trim()

        if (name.isEmpty()) {
            nameEditText.error = "Name is required."
            nameEditText.requestFocus()
            return
        }
        if (email.isEmpty()) {
            emailEditText.error = "Email is required."
            emailEditText.requestFocus()
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.error = "Please enter a valid email."
            emailEditText.requestFocus()
            return
        }

        if (password.isEmpty()) {
            passwordEditText.error = "Password is required."
            passwordEditText.requestFocus()
            return
        }

        if (password != confirmPassword) {
            confirmPasswordEditText.error = "Passwords do not match."
            confirmPasswordEditText.requestFocus()
            return
        }

        firebaseAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = firebaseAuth.currentUser
                    user?.let {
                        saveUserToFirestore(user,email,name)
                    }
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "Registration failed.", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun saveUserToFirestore(user: FirebaseUser, email: String? = null,name: String? = null) {
        val userData = Users(
            uid = user.uid,
            name = name,
            email = email ?: user.email,
            photoUrl = user.photoUrl?.toString()
        )

        val db = FirebaseFirestore.getInstance()
        db.collection("Users").document(user.uid)
            .set(userData)
            .addOnSuccessListener {
                Log.d("AuthHelper", "User data saved successfully in Firestore")
            }
            .addOnFailureListener { e ->
                Log.e("AuthHelper", "Error saving user data in Firestore: $e")
            }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        authHelper.onActivityResult(requestCode, resultCode, data)
    }
}
