package com.example.flashcard.mathtests

import android.graphics.Color
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R

class MatchColumnPageActivity : AppCompatActivity() {

    private var selectedProblem: FrameLayout? = null
    private var selectedProblemText: String? = null
    private var selectedAnswer: FrameLayout? = null
    private var selectedAnswerText: String? = null

    private val correctPairs = hashMapOf(
        "5 + 3 = ?" to "8",
        "10 - 4 = ?" to "6",
        "12 ÷ 4 = ?" to "3",
        "7 × 2 = ?" to "14",
        "15 - 6 = ?" to "9"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.math_matchthecolumn_main)

        // Initialize problem and answer frames
        val problems = listOf(
            findViewById<FrameLayout>(R.id.problem1),
            findViewById<FrameLayout>(R.id.problem2),
            findViewById<FrameLayout>(R.id.problem3),
            findViewById<FrameLayout>(R.id.problem4),
            findViewById<FrameLayout>(R.id.problem5)
        )

        val answers = listOf(
            findViewById<FrameLayout>(R.id.answer1),
            findViewById<FrameLayout>(R.id.answer2),
            findViewById<FrameLayout>(R.id.answer3),
            findViewById<FrameLayout>(R.id.answer4),
            findViewById<FrameLayout>(R.id.answer5)
        )

        val problemTexts = listOf(
            findViewById<TextView>(R.id.problemText1),
            findViewById<TextView>(R.id.problemText2),
            findViewById<TextView>(R.id.problemText3),
            findViewById<TextView>(R.id.problemText4),
            findViewById<TextView>(R.id.problemText5)
        )

        val answerTexts = listOf(
            findViewById<TextView>(R.id.answerText1),
            findViewById<TextView>(R.id.answerText2),
            findViewById<TextView>(R.id.answerText3),
            findViewById<TextView>(R.id.answerText4),
            findViewById<TextView>(R.id.answerText5)
        )

        // Shuffle answers before displaying
        shuffleAnswers(answerTexts)

        // Set click listeners for problems
        for (i in problems.indices) {
            problems[i].setOnClickListener { selectProblem(problems[i], problemTexts[i].text.toString()) }
        }

        // Set click listeners for answers
        for (i in answers.indices) {
            answers[i].setOnClickListener { selectAnswer(answers[i], answerTexts[i].text.toString()) }
        }
    }

    private fun shuffleAnswers(answerTexts: List<TextView>) {
        // Extract answer texts and shuffle them
        val shuffledAnswers = answerTexts.map { it.text.toString() }.shuffled()

        // Assign shuffled answers back to the TextViews
        for (i in answerTexts.indices) {
            answerTexts[i].text = shuffledAnswers[i]
        }
    }

    private fun selectProblem(problem: FrameLayout, text: String) {
        selectedProblem?.setBackgroundResource(R.drawable.rounded_card) // Reset previous selection
        selectedProblem = problem
        selectedProblemText = text
        problem.setBackgroundColor(Color.YELLOW) // Highlight selected problem
    }

    private fun selectAnswer(answer: FrameLayout, text: String) {
        if (selectedProblem == null) {
            Toast.makeText(this, "Select a math problem first!", Toast.LENGTH_SHORT).show()
            return
        }

        selectedAnswer = answer
        selectedAnswerText = text

        checkMatch()
    }

    private fun checkMatch() {
        if (selectedProblemText != null && selectedAnswerText != null) {
            if (correctPairs[selectedProblemText] == selectedAnswerText) {
                selectedProblem?.setBackgroundColor(Color.GREEN)
                selectedAnswer?.setBackgroundColor(Color.GREEN)
                selectedProblem?.isClickable = false
                selectedAnswer?.isClickable = false

                Toast.makeText(this, "Correct match!", Toast.LENGTH_SHORT).show()
            } else {
                selectedProblem?.setBackgroundColor(Color.RED)
                selectedAnswer?.setBackgroundColor(Color.RED)

                Toast.makeText(this, "Incorrect! Try again.", Toast.LENGTH_SHORT).show()

                selectedProblem?.postDelayed({
                    selectedProblem?.setBackgroundResource(R.drawable.rounded_card)
                    selectedAnswer?.setBackgroundResource(R.drawable.rounded_card)
                    selectedProblem = null
                    selectedAnswer = null
                }, 1000)
            }

            // Reset selection variables
            selectedProblem = null
            selectedAnswer = null
        }
    }
}
