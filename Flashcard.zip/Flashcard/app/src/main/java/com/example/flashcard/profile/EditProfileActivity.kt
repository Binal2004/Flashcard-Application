package com.example.flashcard.profile

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.flashcard.R
import com.example.flashcard.authentication.Login
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.userProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage

class EditProfileActivity : AppCompatActivity() {

    private lateinit var progressDialog: AlertDialog
    private lateinit var nameEditIcon: ImageView
    private lateinit var emailEditIcon: ImageView
    private lateinit var editPassword: ImageView
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var editProfileImage: ImageView
    private lateinit var editProfilePhoto: Button
    private lateinit var firestore: FirebaseFirestore
    private lateinit var backArrow:ImageView

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            pickImageFromGallery()
        } else {
            Toast.makeText(this, "Permission denied.", Toast.LENGTH_SHORT).show()
        }
    }

    private val imagePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val selectedImageUri = result.data?.data
            if (selectedImageUri != null) {
                updateProfileImage(selectedImageUri) // Call updateProfileImage here
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        // Initialize views
        nameEditIcon = findViewById(R.id.nameEditIcon)
        emailEditIcon = findViewById(R.id.emailEditIcon)
        editPassword = findViewById(R.id.edit_password)
        nameEditText = findViewById(R.id.nameEditText)
        emailEditText = findViewById(R.id.emailEditText)
        editProfileImage = findViewById(R.id.edit_profile_image)
        editProfilePhoto = findViewById(R.id.edit_profile_photo)
        backArrow = findViewById(R.id.backButton)
        firebaseAuth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()
        // Fetch and display user details


        val currentUser = firebaseAuth.currentUser
        if (currentUser != null) {
            emailEditText.setText(currentUser.email)
            loadProfileImage(currentUser.photoUrl)
            fetchProfileImage()
        }else {
            Toast.makeText(this, "Session expired. Please log in again.", Toast.LENGTH_SHORT).show()
            redirectToLogin()
            return
        }

        // Set up click listeners for edit icons
        setupListeners()
        fetchAndListenForNameUpdates()
//        listenToNameUpdates()
        fetchUserProfile()
    }

    private fun redirectToLogin() {
        startActivity(Intent(this, Login::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        finish()
    }

    private fun loadProfileImage(photoUrl: Uri?) {
        Glide.with(this)
            .load(photoUrl)
            .circleCrop()
            .placeholder(R.drawable.a2)
            .fallback(R.drawable.a1)
            .into(editProfileImage)
    }

    private fun setupListeners() {
        nameEditIcon.setOnClickListener {
            showEditFieldBottomSheet("Change Name", nameEditText.text.toString()) { newName ->
                updateNameInFirestore(newName)
            }
        }

        emailEditIcon.setOnClickListener {
            showEditFieldBottomSheet("Change Email", emailEditText.text.toString()) { newEmail ->
                if (Patterns.EMAIL_ADDRESS.matcher(newEmail).matches()) {
                    val currentUser = firebaseAuth.currentUser
                    if (currentUser != null) {
                        val providers = currentUser.providerData
                        val isGoogleUser = providers.any { it.providerId == GoogleAuthProvider.PROVIDER_ID }

                        if (isGoogleUser) {
                            // Trigger reauthentication and email update for Google users
                            reauthenticateAndChangeGoogleEmail(newEmail)
                        } else {
                            // Show reauthentication prompt for email/password users
                            showReauthenticationBottomSheet(newEmail)
                        }
                    }
                } else {
                    Toast.makeText(this, "Invalid email address.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        backArrow.setOnClickListener {
            finish()
        }

        editPassword.setOnClickListener {
            showChangePasswordBottomSheet()
        }

        editProfilePhoto.setOnClickListener {
            Log.d("EditProfile", "Edit Photo clicked.")
            checkAndRequestPermission()
        }

    }

    private fun checkAndRequestPermission() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        when {
            // Permission already granted
            ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED -> {
                pickImageFromGallery()
            }
            // Show rationale dialog if needed
            shouldShowRequestPermissionRationale(permission) -> {
                showPermissionRationaleDialog(permission)
            }
            // No rationale needed (first time or "Don't ask again")
            else -> {
                permissionLauncher.launch(permission)
            }
        }
    }

    private fun showPermissionRationaleDialog(permission: String) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Permission Required")
            .setMessage("This app requires permission to access your photos to select an image.")
            .setPositiveButton("Allow") { _, _ ->
                permissionLauncher.launch(permission)
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun pickImageFromGallery() {
        Log.d("EditProfile", "Launching gallery intent.")
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
            type = "image/*"
        }
        imagePickerLauncher.launch(intent)
    }

    private fun fetchUserProfile() {
        val user = firebaseAuth.currentUser
        user?.let {
            emailEditText.setText(it.email)
            fetchProfileImage()
            fetchAndListenForNameUpdates()
        } ?: run {
            Toast.makeText(this, "Session expired. Please log in again.", Toast.LENGTH_SHORT).show()
            redirectToLogin()
        }
    }

    private fun fetchProfileImage() {
        val userId = firebaseAuth.currentUser?.uid ?: return
        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val cachedImageUrl = sharedPreferences.getString("profileImage", null)

        if (!cachedImageUrl.isNullOrEmpty()) {
            Log.d("EditProfileActivity", "Loaded profile image from cache: $cachedImageUrl")

            Glide.with(this)
                .load(cachedImageUrl)
                .circleCrop()
                .placeholder(R.drawable.a2)
                .error(R.drawable.a1)
                .into(editProfileImage)
        } else {
            // ✅ Fetch from Firebase Storage only if not cached
            val storageRef = FirebaseStorage.getInstance().reference.child("profile_images/$userId.jpg")

            storageRef.downloadUrl
                .addOnSuccessListener { uri ->
                    val imageUrl = uri.toString()
                    Log.d("EditProfileActivity", "Fetched image URL from Storage: $imageUrl")

                    // ✅ Save to SharedPreferences to persist image
                    with(sharedPreferences.edit()) {
                        putString("profileImage", imageUrl)
                        apply()
                    }

                    Glide.with(this)
                        .load(imageUrl)
                        .circleCrop()
                        .placeholder(R.drawable.a2)
                        .error(R.drawable.a1)
                        .into(editProfileImage)
                }
                .addOnFailureListener { e ->
                    Log.e("EditProfileActivity", "Failed to fetch profile image from Storage: ${e.message}")
                }
        }
    }

    private fun updateProfileImage(uri: Uri) {
        showCustomProgressDialog("Uploading your profile picture...")

        val userId = firebaseAuth.currentUser?.uid ?: return
        val storageRef = FirebaseStorage.getInstance().reference.child("profile_images/$userId.jpg")

        storageRef.putFile(uri)
            .addOnSuccessListener {
                storageRef.downloadUrl.addOnSuccessListener { downloadUri ->
                    val imageUrl = downloadUri.toString()
                    Log.d("UpdateProfileImage", "New Image URL: $imageUrl")

                    // ✅ Save URL to SharedPreferences for persistence
                    val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
                    with(sharedPreferences.edit()) {
                        putString("profileImage", imageUrl)
                        apply()
                    }

                    dismissCustomProgressDialog()

                    // ✅ Update UI immediately
                    Glide.with(this)
                        .load(imageUrl)
                        .circleCrop()
                        .placeholder(R.drawable.a2)
                        .error(R.drawable.a1)
                        .into(editProfileImage)

                    Toast.makeText(this, "Image uploaded successfully!", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                dismissCustomProgressDialog()
                Toast.makeText(this, "Failed to upload image.", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showCustomProgressDialog(message: String = "Uploading...") {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.custom_progress_dialog, null)
        val progressText: TextView = dialogView.findViewById(R.id.progressText)
        progressText.text = message

        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        builder.setCancelable(false) // Prevent closing the dialog on back press

        progressDialog = builder.create()
        progressDialog.show()
    }

    private fun dismissCustomProgressDialog() {
        if (::progressDialog.isInitialized && progressDialog.isShowing) {
            progressDialog.dismiss()
        }
    }

    private fun fetchAndListenForNameUpdates() {
        val userId = firebaseAuth.currentUser?.uid ?: return

        firestore.collection("Users").document(userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("Firestore", "Failed to listen for name updates: ${error.message}")
                    return@addSnapshotListener
                }

                if (snapshot != null && snapshot.exists()) {
                    val name = snapshot.getString("name")
                    if (name != nameEditText.text.toString()) {
                        nameEditText.setText(name ?: "")
                    }
                }
            }
    }

    private fun updateNameInDatabase(newName: String) {
        val userId = firebaseAuth.currentUser?.uid ?: return
        val userDatabaseRef = FirebaseDatabase.getInstance().getReference("users").child(userId)

        userDatabaseRef.child("name").setValue(newName)
            .addOnSuccessListener {
                Toast.makeText(this, "Name updated successfully.", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to update name in database.", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateNameInFirestore(newName: String) {
        val userId = firebaseAuth.currentUser?.uid ?: return

        // Validate the new name
        if (newName.isBlank()) {
            Toast.makeText(this, "Name cannot be empty.", Toast.LENGTH_SHORT).show()
            return
        }

        firestore.collection("Users").document(userId).update("name", newName)
            .addOnSuccessListener {
                nameEditText.setText(newName) // Update UI directly after success
                updateFirebaseDisplayName(newName) // Update Firebase Auth profile
                updateNameInDatabase(newName) // Sync with Realtime Database if needed
                Toast.makeText(this, "Name updated successfully.", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Failed to update name: ${e.message}")
                Toast.makeText(this, "Failed to update name.", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateFirebaseDisplayName(newName: String) {
        val profileUpdates = userProfileChangeRequest { displayName = newName }
        firebaseAuth.currentUser?.updateProfile(profileUpdates)
    }

    private fun showReauthenticationBottomSheet(newEmail: String) {
        val bottomSheetDialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottom_sheet_password_prompt, null)
        bottomSheetDialog.setContentView(view)

        val passwordEditText = view.findViewById<EditText>(R.id.password_EditText)
        val confirmButton = view.findViewById<Button>(R.id.confirm_Button)

        confirmButton.setOnClickListener {
            val currentPassword = passwordEditText.text.toString().trim()
            if (currentPassword.isNotEmpty()) {
                bottomSheetDialog.dismiss()
                reauthenticateUserAndChangeEmail(currentPassword, newEmail)
            } else {
                passwordEditText.error = "Password is required"
                passwordEditText.requestFocus()
            }
        }

        bottomSheetDialog.show()
    }

    private fun reauthenticateUserAndChangeEmail(currentPassword: String, newEmail: String) {
        val currentUser = firebaseAuth.currentUser ?: return
        val credential = EmailAuthProvider.getCredential(currentUser.email!!, currentPassword)

        currentUser.reauthenticate(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    savePendingEmailToFirestore(newEmail) // Save the pending email
                    sendVerificationLinkToNewEmail(newEmail)
                } else {
                    Toast.makeText(this, "Reauthentication failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun sendVerificationLinkToNewEmail(newEmail: String) {
        val currentUser = firebaseAuth.currentUser ?: return

        currentUser.verifyBeforeUpdateEmail(newEmail)
            .addOnSuccessListener {
                showLogoutConfirmationDialog(newEmail) // Show confirmation dialog
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to send verification email: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showLogoutConfirmationDialog(newEmail: String) {
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Email Change Confirmation")
            .setMessage(
                "A verification email has been sent to $newEmail. Once verified, you will need to log in again. Do you want to proceed with logging out?"
            )
            .setPositiveButton("Log Out") { _, _ ->
                clearGoogleSignInCache()
                notifyLogoutAndRedirect()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .create()

        dialog.show()
    }

    private fun clearGoogleSignInCache() {
        val googleSignInClient = GoogleSignIn.getClient(
            this,
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build()
        )
        googleSignInClient.signOut().addOnCompleteListener {
            Log.d("GoogleSignOut", "Google Sign-In cache cleared.")
        }
    }

    private fun savePendingEmailToFirestore(newEmail: String) {
        val userId = firebaseAuth.currentUser?.uid ?: return
        firestore.collection("Users").document(userId).update("pending_email", newEmail)
            .addOnSuccessListener {
                Log.d("Firestore", "Pending email saved successfully for email/password user.")
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Failed to save pending email: ${e.message}")
            }
    }

    private fun notifyLogoutAndRedirect() {
        Toast.makeText(this, "You will be logged out. Please log in with your new email.", Toast.LENGTH_LONG).show()
        firebaseAuth.signOut()
        startActivity(Intent(this, Login::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        finish()
    }

    private fun reauthenticateAndChangeGoogleEmail(newEmail: String) {

        val currentUser = firebaseAuth.currentUser
        if (currentUser != null) {
            savePendingEmailToFirestore(newEmail)
            // Get the last signed-in Google account
            val googleSignInAccount = GoogleSignIn.getLastSignedInAccount(this)

            if (googleSignInAccount != null) {
                // Create a Google credential using the ID token
                val credential = GoogleAuthProvider.getCredential(googleSignInAccount.idToken, null)

                // Reauthenticate with the Google credential
                currentUser.reauthenticate(credential)
                    .addOnCompleteListener { reauthTask ->
                        if (reauthTask.isSuccessful) {
                            // Proceed with updating the email using `verifyBeforeUpdateEmail`
                            currentUser.verifyBeforeUpdateEmail(newEmail)
                                .addOnCompleteListener { updateTask ->
                                    if (updateTask.isSuccessful) {
                                        Toast.makeText(
                                            this,
                                            "Verification email sent to $newEmail. Please verify to complete the update.",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        notifyLogoutAndRedirect() // Log out after sending verification
                                    } else {
                                        Toast.makeText(
                                            this,
                                            "Failed to send verification email: ${updateTask.exception?.message}",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                        } else {
                            Toast.makeText(
                                this,
                                "Reauthentication failed: ${reauthTask.exception?.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
            } else {
                Toast.makeText(
                    this,
                    "Google account not found. Please log in again.",
                    Toast.LENGTH_SHORT
                ).show()
                redirectToLogin()
            }
        } else {
            Toast.makeText(this, "User not logged in.", Toast.LENGTH_SHORT).show()
            redirectToLogin()
        }
    }

    private fun showEditFieldBottomSheet(title: String, currentValue: String, onSave: (String) -> Unit) {
        val bottomSheetDialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottom_sheet_edit_field, null)
        bottomSheetDialog.setContentView(view)

        val titleTextView = view.findViewById<TextView>(R.id.titleTextView)
        val editField = view.findViewById<EditText>(R.id.editField)
        val saveButton = view.findViewById<Button>(R.id.saveButton)

        titleTextView.text = title
        editField.setText(currentValue)

        saveButton.setOnClickListener {
            val newValue = editField.text.toString().trim()
            if (newValue.isEmpty()) {
                editField.error = "This field cannot be empty."
            } else if (title.contains("Email", ignoreCase = true) && !Patterns.EMAIL_ADDRESS.matcher(newValue).matches()) {
                editField.error = "Please enter a valid email address."
            } else {
                onSave(newValue)
                bottomSheetDialog.dismiss()
            }
        }

        bottomSheetDialog.show()
    }

    private fun showForgotPasswordBottomSheet() {
        val bottomSheetDialog = BottomSheetDialog(this)
        val view = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_forgot_password, null)
        bottomSheetDialog.setContentView(view)

        val resetEmailEditText = view.findViewById<EditText>(R.id.resetEmailEditText)
        val sendCodeButton = view.findViewById<Button>(R.id.sendCodeButton)

        sendCodeButton.setOnClickListener {
            val email = resetEmailEditText.text.toString().trim()

            if (email.isEmpty()) {
                resetEmailEditText.error = "Email is required."
                resetEmailEditText.requestFocus()
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                resetEmailEditText.error = "Please enter a valid email."
                resetEmailEditText.requestFocus()
                return@setOnClickListener
            }

            firebaseAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Reset email sent.", Toast.LENGTH_SHORT).show()
                        bottomSheetDialog.dismiss()
                    } else {
                        Toast.makeText(this, "Error sending reset email.", Toast.LENGTH_SHORT).show()
                    }
                }
        }

        bottomSheetDialog.show()
    }

    private fun showChangePasswordBottomSheet() {
        val bottomSheetDialog = BottomSheetDialog(this)
        val view = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_change_password, null)
        bottomSheetDialog.setContentView(view)

        val currentPasswordEditText = view.findViewById<EditText>(R.id.currentPassword)
        val newPasswordEditText = view.findViewById<EditText>(R.id.newPassword)
        val confirmPasswordEditText = view.findViewById<EditText>(R.id.confirmPassword)
        val saveButton = view.findViewById<Button>(R.id.saveButton)
        val forgetPassword = view.findViewById<TextView>(R.id.forgotPassword)

        forgetPassword.setOnClickListener {
            showForgotPasswordBottomSheet()
        }

        saveButton.setOnClickListener {
            val currentPassword = currentPasswordEditText.text.toString().trim()
            val newPassword = newPasswordEditText.text.toString().trim()
            val confirmPassword = confirmPasswordEditText.text.toString().trim()

            // Validate input fields
            if (currentPassword.isEmpty()) {
                currentPasswordEditText.error = "Current password is required."
                return@setOnClickListener
            }
            if (newPassword.isEmpty()) {
                newPasswordEditText.error = "New password is required."
                return@setOnClickListener
            }
            if (confirmPassword.isEmpty()) {
                confirmPasswordEditText.error = "Confirm password is required."
                return@setOnClickListener
            }
            if (newPassword != confirmPassword) {
                confirmPasswordEditText.error = "Passwords do not match."
                return@setOnClickListener
            }

            // Get current user
            val currentUser = firebaseAuth.currentUser
            if (currentUser != null) {
                // Reauthenticate the user
                val email = currentUser.email
                if (email != null) {
                    val credential = EmailAuthProvider.getCredential(email, currentPassword)

                    currentUser.reauthenticate(credential)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                // Update password
                                currentUser.updatePassword(newPassword)
                                    .addOnCompleteListener { updateTask ->
                                        if (updateTask.isSuccessful) {
                                            Toast.makeText(
                                                this,
                                                "Password updated successfully.",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            bottomSheetDialog.dismiss()
                                        } else {
                                            Toast.makeText(
                                                this,
                                                "Failed to update password: ${updateTask.exception?.message}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                            } else {
                                currentPasswordEditText.error = "Incorrect current password."
                            }
                        }
                } else {
                    Toast.makeText(this, "User email is not available.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "No user is logged in.", Toast.LENGTH_SHORT).show()
            }
        }

        bottomSheetDialog.show()
    }

}
