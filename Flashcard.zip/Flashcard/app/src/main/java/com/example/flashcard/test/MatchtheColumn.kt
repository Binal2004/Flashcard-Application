package com.example.flashcard.test

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R
import com.example.flashcard.folder.MathTests

class MatchtheColumn : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_matchthe_column)

        // Back button logic
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            val intent = Intent(this, MathTests::class.java)
            startActivity(intent)
            finish() // Close the current activity to avoid stacking
        }
    }
}
