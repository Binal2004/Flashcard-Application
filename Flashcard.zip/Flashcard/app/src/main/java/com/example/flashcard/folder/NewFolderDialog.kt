package com.example.flashcard.folder

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Window
import android.widget.Button
import android.widget.EditText
import com.example.flashcard.R

class NewFolderDialog(
    context: Context,
    private val onFolderCreated: (String) -> Unit // Callback when folder is created
) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_dialog) // Use your XML file for the dialog

        val folderNameInput = findViewById<EditText>(R.id.sessionNameInput)
        val createButton = findViewById<Button>(R.id.createButton)

        createButton.setOnClickListener {
            val folderName = folderNameInput.text.toString().trim()
            if (folderName.isNotEmpty()) {
                onFolderCreated(folderName) // Pass folder name back to activity
                dismiss() // Close dialog after folder creation
            } else {
                folderNameInput.error = "Folder name cannot be empty"
            }
        }
    }
}
