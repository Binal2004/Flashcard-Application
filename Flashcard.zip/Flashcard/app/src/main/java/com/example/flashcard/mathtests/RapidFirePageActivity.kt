package com.example.flashcard.mathtests

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R
import com.example.flashcard.folder.MathTests
import kotlin.random.Random

class RapidFirePageActivity : AppCompatActivity() {

    private lateinit var timerTextView: TextView
    private lateinit var submitButton: Button
    private var correctAnswers = mutableMapOf<String, Int>()
    private var score = 0
    private var timer: CountDownTimer? = null
    private val totalTime: Long = 60000  // 60 seconds
    private val interval: Long = 1000  // 1 second

    private lateinit var questionViews: List<TextView>
    private lateinit var answerInputs: List<EditText>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.math_rapidfire_main)

        // Initialize UI elements
        timerTextView = findViewById(R.id.timerTextView)
        submitButton = findViewById(R.id.submitButton)

        // Back button logic
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            val intent = Intent(this, MathTests::class.java)
            startActivity(intent)
            finish()
        }

        // Initialize question and answer fields
        questionViews = listOf(
            findViewById(R.id.question1), findViewById(R.id.question2),
            findViewById(R.id.question3), findViewById(R.id.question4),
            findViewById(R.id.question10)
        )

        answerInputs = listOf(
            findViewById(R.id.answer1), findViewById(R.id.answer2),
            findViewById(R.id.answer3), findViewById(R.id.answer4),
            findViewById(R.id.answer10)
        )

        generateMathQuestions()
        startTimer()

        submitButton.setOnClickListener {
            checkAnswers()
        }
    }

    private fun generateMathQuestions() {
        correctAnswers.clear()

        for (i in questionViews.indices) {
            val num1 = Random.nextInt(1, 20)
            val num2 = Random.nextInt(1, 20)
            val operation = listOf("+", "-", "×", "÷").random()

            val questionText: String
            val correctAnswer: Int

            when (operation) {
                "+" -> {
                    questionText = "$num1 + $num2 = ?"
                    correctAnswer = num1 + num2
                }
                "-" -> {
                    questionText = "$num1 - $num2 = ?"
                    correctAnswer = num1 - num2
                }
                "×" -> {
                    questionText = "$num1 × $num2 = ?"
                    correctAnswer = num1 * num2
                }
                "÷" -> {
                    val num3 = num1 * num2  // Ensures division is always valid
                    questionText = "$num3 ÷ $num1 = ?"
                    correctAnswer = num2
                }
                else -> continue
            }

            questionViews[i].text = questionText
            correctAnswers[questionText] = correctAnswer
        }
    }

    private fun startTimer() {
        timer = object : CountDownTimer(totalTime, interval) {
            override fun onTick(millisUntilFinished: Long) {
                timerTextView.text = "${millisUntilFinished / 1000}s"
            }

            override fun onFinish() {
                submitButton.performClick()
                timerTextView.text = "Time's up!"
            }
        }.start()
    }

    private fun checkAnswers() {
        score = 0

        for (i in questionViews.indices) {
            val userAnswer = answerInputs[i].text.toString().toIntOrNull()
            val correctAnswer = correctAnswers[questionViews[i].text.toString()]

            if (userAnswer == correctAnswer) {
                score++
            }
        }

        // Show Score Popup
        showScorePopup()
        timer?.cancel()
    }

    private fun showScorePopup() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_score_popup, null)
        val scoreTextView: TextView = dialogView.findViewById(R.id.scoreText)
        val okButton: Button = dialogView.findViewById(R.id.okButton)

        // Set the score dynamically
        scoreTextView.text = "Your Score: $score/5"

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        // Close popup when "OK" is clicked
        okButton.setOnClickListener {
            dialog.dismiss()
        }

        // Show popup
        dialog.show()
    }

}
