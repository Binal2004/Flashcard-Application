package com.example.flashcard.computertests

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R
import com.example.flashcard.folder.ComputerTests

class RapidFirePageActivity2 : AppCompatActivity() {

    private lateinit var timerTextView: TextView
    private lateinit var submitButton: Button
    private var correctAnswers = mutableMapOf<String, String>()
    private var score = 0
    private var timer: CountDownTimer? = null
    private val totalTime: Long = 60000  // 60 seconds
    private val interval: Long = 1000  // 1 second

    private lateinit var questionViews: List<TextView>
    private lateinit var answerInputs: List<EditText>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.computer_rapidfire_main)

        // Initialize UI elements
        timerTextView = findViewById(R.id.timerTextView)
        submitButton = findViewById(R.id.submitButton)

        // Back button logic
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            val intent = Intent(this, ComputerTests::class.java)
            startActivity(intent)
            finish()
        }

        // Initialize question and answer fields
        questionViews = listOf(
            findViewById(R.id.question1), findViewById(R.id.question2),
            findViewById(R.id.question3),  findViewById(R.id.question10),
            findViewById(R.id.question11)
        )

        answerInputs = listOf(
            findViewById(R.id.answer1), findViewById(R.id.answer2),
            findViewById(R.id.answer3), findViewById(R.id.answer10),
            findViewById(R.id.answer11)
        )

        loadComputerScienceQuestions()
        startTimer()

        submitButton.setOnClickListener {
            checkAnswers()
        }
    }

    private fun loadComputerScienceQuestions() {
        correctAnswers.clear()

        val questionsAndAnswers = listOf(
            "What does CPU stand for?" to "Central Processing Unit",
            "What is the main function of RAM?" to "Temporary storage",
            "What does HTML stand for?" to "HyperText Markup Language",
            "What does CSS stand for?" to "Cascading Style Sheets",
            "What is the full form of SQL?" to "Structured Query Language",
            "What does API stand for?" to "Application programming interface",
            "What is the default file extension for Python files?" to ".py",
            "What does GUI stand for?" to "Graphical User Interface",
            "What is an IP address?" to "A unique identifier for a device on a network",
            "What does HTTP stand for?" to "HyperText Transfer Protocol"
        )

        for (i in questionViews.indices) {
            val (question, answer) = questionsAndAnswers[i]
            questionViews[i].text = question
            correctAnswers[question] = answer
        }
    }

    private fun startTimer() {
        timer = object : CountDownTimer(totalTime, interval) {
            override fun onTick(millisUntilFinished: Long) {
                timerTextView.text = "${millisUntilFinished / 1000}s"
            }

            override fun onFinish() {
                submitButton.performClick()
                timerTextView.text = "Time's up!"
            }
        }.start()
    }

    private fun checkAnswers() {
        score = 0

        for (i in questionViews.indices) {
            val userAnswer = answerInputs[i].text.toString().trim()
            val correctAnswer = correctAnswers[questionViews[i].text.toString()] ?: ""

            if (userAnswer.equals(correctAnswer, ignoreCase = true)) {
                score++
            }
        }

        // Show Score Popup
        showScorePopup()
        timer?.cancel()
    }

    private fun showScorePopup() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_score_popup, null)
        val scoreTextView: TextView = dialogView.findViewById(R.id.scoreText)
        val okButton: Button = dialogView.findViewById(R.id.okButton)

        // Set the score dynamically
        scoreTextView.text = "Your Score: $score/5"

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        // Close popup when "OK" is clicked
        okButton.setOnClickListener {
            dialog.dismiss()
        }

        // Show popup
        dialog.show()
    }
}
