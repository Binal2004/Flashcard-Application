package com.example.flashcard.sciencetests

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.R
import com.example.flashcard.folder.ScienceTests

class MCQPageActivity1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sciencemcq_main)

        // Back button logic
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            val intent = Intent(this, ScienceTests::class.java)
            startActivity(intent)
            finish() // Close the current activity to avoid stacking
        }

        val correctAnswers = mapOf(
            R.id.option1_1 to true, // Question 1
            R.id.option2_1 to true, // Question 2
            R.id.option3_1 to true, // Question 3
            R.id.option4_1 to true, // Question 4
            R.id.option5_1 to true, // Question 5
            R.id.option6_1 to true, // Question 6
            R.id.option7_1 to true, // Question 7
            R.id.option8_1 to true, // Question 8
            R.id.option9_1 to true, // Question 9
            R.id.option10_1 to true // Question 10
        )

        val submitButton = findViewById<Button>(R.id.submitButton)
        submitButton.setOnClickListener {
            val userScore = calculateScore(correctAnswers)
            showScoreDialog(userScore, correctAnswers.size)
        }
    }

    private fun calculateScore(correctAnswers: Map<Int, Boolean>): Int {
        var score = 0

        correctAnswers.keys.forEach { optionId ->
            val radioButton = findViewById<RadioButton>(optionId)
            if (radioButton.isChecked) {
                score++
            }
        }

        return score
    }

    private fun showScoreDialog(score: Int, totalQuestions: Int) {
        val dialogView = layoutInflater.inflate(R.layout.custom_dialog, null)

        val title = dialogView.findViewById<TextView>(R.id.dialogTitle)
        val message = dialogView.findViewById<TextView>(R.id.dialogMessage)
        val button = dialogView.findViewById<Button>(R.id.dialogButton)

        title.text = "Test Result"
        message.text = "You scored $score out of $totalQuestions."

        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)

        val dialog = builder.create()
        dialog.show()

        button.setOnClickListener {
            dialog.dismiss()
        }
    }
}
