package com.example.flashcard.profile

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.flashcard.R
import com.example.flashcard.authentication.Login
import com.example.flashcard.ui.Chatbot // Added Chatbot Import
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class ProfileFragment : Fragment() {

    private lateinit var profileImage: ImageView
    private lateinit var userName: TextView
    private lateinit var userEmail: TextView
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private var userDetailsListener: ListenerRegistration? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        // Initialize views
        profileImage = view.findViewById(R.id.profileImage)
        userName = view.findViewById(R.id.user_name)
        userEmail = view.findViewById(R.id.user_email)
        firebaseAuth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Fetch user details
        fetchUserDetails()

        // Find views for the options
        val editProfileOption = view.findViewById<Button>(R.id.editProfileButton)
        val aboutUs = view.findViewById<LinearLayout>(R.id.about_us)
        val logoutBtn = view.findViewById<LinearLayout>(R.id.logout_btn)
        val hoverButton = view.findViewById<ImageButton>(R.id.hoverButton) // Chatbot Button

        // Set click listener to navigate to Edit Profile
        editProfileOption.setOnClickListener {
            val intent = Intent(activity, EditProfileActivity::class.java)
            startActivity(intent)
        }

        aboutUs.setOnClickListener {
            val intent = Intent(requireContext(), AboutUsActivity::class.java)
            startActivity(intent)
        }

        // ✅ Set click listener for Chatbot Button
        hoverButton.setOnClickListener {
            openChatbot()
        }

        // Set click listener for logout button
        logoutBtn.setOnClickListener {
            showLogoutConfirmationDialog()
        }

        return view
    }
    // ✅ Function to Open Chatbot Activity
    private fun openChatbot() {
        val intent = Intent(activity, Chatbot::class.java)
        startActivity(intent)
    }

    private fun fetchUserDetails() {
        val currentUser = firebaseAuth.currentUser
        if (currentUser != null) {
            val userId = currentUser.uid
            userEmail.text = currentUser.email
            userDetailsListener = firestore.collection("Users").document(userId)
                .addSnapshotListener { snapshot, error ->
                    if (!isAdded || context == null) {
                        Log.w("ProfileFragment", "Fragment is not attached. Skipping snapshot updates.")
                        return@addSnapshotListener
                    }

                    if (error != null) {
                        Log.e("ProfileFragment", "Error fetching user details: ${error.message}", error)
                        return@addSnapshotListener
                    }

                    if (snapshot != null && snapshot.exists()) {
                        val imageUrl = snapshot.getString("profileImage")
                        if (!imageUrl.isNullOrEmpty()) {
                            Glide.with(this)
                                .load(imageUrl)
                                .circleCrop()
                                .placeholder(R.drawable.user_profile)
                                .into(profileImage)
                        } else {
                            profileImage.setImageResource(R.drawable.a4)
                        }

                        val name = snapshot.getString("name")
                        userName.text = name ?: "Guest"
                    }
                }
        } else {
            Log.e("ProfileFragment", "User not logged in")
            redirectToLogin()
        }
    }

    private fun redirectToLogin() {
        val intent = Intent(requireContext(), Login::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        requireActivity().finish()
    }

    private fun fetchNameFromDatabase(userId: String) {
        val userDatabaseRef = FirebaseDatabase.getInstance().getReference("users").child(userId)

        // Add a value event listener for real-time updates
        userDatabaseRef.child("name").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val name = snapshot.getValue(String::class.java)
                userName.text = name ?: "Guest"
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to fetch name: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        fetchUserDetails() // Re-fetch user details when the fragment resumes
    }

    override fun onDestroyView() {
        super.onDestroyView()
        userDetailsListener?.remove()
        userDetailsListener = null
        Log.d("ProfileFragment", "Firestore listener removed in onDestroyView")
    }

    private fun showLogoutConfirmationDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Logout")
        builder.setMessage("Are you sure you want to logout?")

        // "Yes" button
        builder.setPositiveButton("Yes") { _, _ ->
            logoutUser()
        }

        // "No" button
        builder.setNegativeButton("No") { dialog, _ ->
            dialog.dismiss()
        }

        val dialog = builder.create()
        dialog.show()
    }

    private fun logoutUser() {
        val firebaseAuth = FirebaseAuth.getInstance()

        // Log out from Google
        val googleSignInClient = GoogleSignIn.getClient(
            requireContext(),
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build()
        )
        googleSignInClient.signOut().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                // Log out from Firebase
                firebaseAuth.signOut()

                // Log out from Facebook
                val accessToken = com.facebook.AccessToken.getCurrentAccessToken()
                if (accessToken != null && !accessToken.isExpired) {
                    com.facebook.login.LoginManager.getInstance().logOut()
                }

                // Redirect to login activity
                val intent = Intent(activity, Login::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)

                Toast.makeText(requireContext(), "Successfully logged out", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Google sign-out failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
