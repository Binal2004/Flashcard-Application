package com.example.flashcard.HomeScreen

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.flashcard.R
import com.example.flashcard.folder.FoldersFragment
import com.example.flashcard.live.LiveFragment
import com.example.flashcard.profile.ProfileFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class HomeActivity : AppCompatActivity() {

    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        replaceFragment(HomeFragment())

        setupNavigation()
        setupFab()
    }

    private fun setupNavigation() {
        findViewById<ImageView>(R.id.icon_home).setOnClickListener {
            replaceFragment(HomeFragment())
        }

        findViewById<ImageView>(R.id.icon_video).setOnClickListener {
            replaceFragment(LiveFragment())
        }

        findViewById<ImageView>(R.id.icon_profile).setOnClickListener {
            replaceFragment(ProfileFragment())
        }

        findViewById<ImageView>(R.id.icon_folders).setOnClickListener {
            replaceFragment(FoldersFragment())
        }
    }

    private fun setupFab() {
        findViewById<ImageView>(R.id.fab).setOnClickListener {
            showCreateFolderDialog()
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.homefragment, fragment)
            .commit()
    }

    private fun showCreateFolderDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.activity_dialog, null)
        val dialog = Dialog(this, R.style.CustomDialog)
        dialog.setContentView(dialogView)

        val sessionNameInput = dialogView.findViewById<EditText>(R.id.sessionNameInput)
        val createButton = dialogView.findViewById<Button>(R.id.createButton)

        createButton.setOnClickListener {
            val folderName = sessionNameInput.text.toString().trim()
            if (folderName.isNotEmpty()) {
                createFolder(folderName)
                dialog.dismiss()
            } else {
                sessionNameInput.error = "Folder name cannot be empty"
            }
        }

        dialog.show()
    }

    private fun createFolder(folderName: String) {
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            Toast.makeText(this, "You need to log in first", Toast.LENGTH_SHORT).show()
            return
        }

        val folderId = UUID.randomUUID().toString()
        val folderData = hashMapOf(
            "id" to folderId,
            "name" to folderName,
            "timestamp" to System.currentTimeMillis(),
            "ownerId" to user.uid // Store user ID to track ownership
        )

        db.collection("folders").document(folderId)
            .set(folderData)
            .addOnSuccessListener {
                Toast.makeText(this, "Folder created successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to create folder: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    fun showEditFolderDialog(folderId: String, currentName: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Rename Folder")

        val input = EditText(this)
        input.setText(currentName)
        builder.setView(input)

        builder.setPositiveButton("Update") { _, _ ->
            val newFolderName = input.text.toString().trim()
            if (newFolderName.isNotEmpty()) {
                updateFolderName(folderId, newFolderName)
            } else {
                Toast.makeText(this, "Folder name cannot be empty!", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun updateFolderName(folderId: String, newName: String) {
        db.collection("folders").document(folderId)
            .update("name", newName)
            .addOnSuccessListener {
                Toast.makeText(this, "Folder Renamed", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    fun showDeleteConfirmationDialog(folderId: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Delete Folder")
        builder.setMessage("Are you sure you want to delete this folder?")

        builder.setPositiveButton("Delete") { _, _ ->
            deleteFolder(folderId)
        }

        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun deleteFolder(folderId: String) {
        db.collection("folders").document(folderId)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(this, "Folder Deleted", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
